export const GetMaintenance=(state:any)=>state.Maintenance.data;
export const GetProperty=(state:any)=>state.Property.data;
