export const tenantSelector = (state: any) => state.TenantSlice.data;
export const singleTenantSelector = (state: any) =>
	state.TenantSlice.singleData;
