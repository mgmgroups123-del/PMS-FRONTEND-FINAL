export const selectLand = (state: any) => state.landstore.lands;
