export const selectLeasemanagement = (state: any) => state.LeasemanagementSlice.data;
export const selectIdLease = (state: any) => state.LeaseIdSlice.data2;