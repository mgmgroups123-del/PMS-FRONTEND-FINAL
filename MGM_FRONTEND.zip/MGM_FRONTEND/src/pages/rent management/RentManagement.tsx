import Rent from '../../components/RentManagement/Rent'

function RentManagement() {
	return (
		<div className='p-3'>
			<Rent />
		</div>
	);
}

export default RentManagement;
